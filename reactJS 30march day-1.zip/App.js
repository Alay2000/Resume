import Todos from "./Components/Todos/Todos";
function App() {
  const INITIAL_TODO = [
    {
      id: "T1",
      title: "This is first title new",
      priority: "High",
      date: new Date(2022, 7, 15),
    },
    {
      id: "T2",
      title: "This is second title",
      priority: "Low",
      date: new Date(2022, 8, 15),
    },
    {
      id: "T3",
      title: "This is third title",
      priority: "Medium",
      date: new Date(2021, 8, 15),
    },
    {
      id: "T4",
      title: "This is fourth title",
      priority: "Medium",
      date: new Date(2022, 4, 25),
    },
  ];
  return (
    <div>
      <Todos todo={INITIAL_TODO} />
    </div>
  );
}

export default App;

{
  /**
require
1.import statments - optional
2.function , arrow , class - 
    - return
3. export default 
*/
}
