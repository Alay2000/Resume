import { useState } from "react";
import "./TodoItem.css";
import TodoDate from "../TodoDate/TodoDate";
import Card from "../UI/Card/Card";

function TodoItem(props) {
  const [usertitle, setTitle] = useState(props.title);
  const [textChange, setTextChanged] = useState(false);
  const [newPriority, setPriority] = useState(props.priority);
  let title = props.title;
  const todoDate = props.date;
  const priority = props.priority;

  const buttonClickHandler = () => {
    setTitle("this is new data for the text");
    setTextChanged((abc) => !abc);
    setPriority("High");
    //  title = "This is new updated title";
    console.log(usertitle);
  };

  return (
    <Card className="todo-item">
      {/* Date was here */}
      <TodoDate userDate={todoDate} />
      <div className="todo-description">
        <h2
          className={` 
          ${textChange == true ? "color2" : "color1"}`}
        >
          {usertitle}
        </h2>
        <div className="todo-priority">{newPriority}</div>
        <button onClick={buttonClickHandler}>Change Text</button>
      </div>
    </Card>
  );
}

export default TodoItem;
{
  /**
1.const <name> = props.propertyname
2. {props.propertyname} = JSX 
3. const {} =props = inside the function
4. {}=props = as a parameter


App ->TodoItem ->todoDate
                -> TodoItem.css

hooks -> useState()
                */
}
